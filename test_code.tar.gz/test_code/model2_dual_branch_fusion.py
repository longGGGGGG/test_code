"""
模型2: 双分支CNN-LSTM + 交叉注意力 + 自适应特征融合 (Gas Concentration Prediction)

架构设计:
    输入 (seq_len, 4) 传感器时间序列
    ┌─ 分支A: 空间分支 (深层CNN) ─ 提取传感器间空间相关性和局部模式
    │    → 残差CNN块 × 3 → 空间注意力
    │
    └─ 分支B: 时序分支 (BiLSTM) ─ 捕捉长程时间依赖
         → BiLSTM × 2 → 时序自注意力
    
    → 交叉注意力 (两分支互相增强)
    → 自适应门控融合 (学习最优融合权重)
    → MLP回归头
    → 输出浓度预测值

创新点:
    1. 双分支并行架构: CNN擅长局部模式, LSTM擅长长程依赖, 互补提取特征
    2. 交叉注意力机制: 两分支特征互相查询, 增强信息交互
    3. 自适应门控融合: 可学习的融合权重, 而非简单拼接
    4. 残差连接: 缓解深层网络退化问题
"""

import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

import time
import logging
import torch
import torch.nn as nn
import torch.optim as optim
import torch.utils.data
import numpy as np
import glob
import torch.nn.functional as F
from tqdm import tqdm
import pandas as pd
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.model_selection import KFold
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Helvetica', 'Arial']
matplotlib.rcParams['axes.unicode_minus'] = False


def setup_logger(name, log_file, level=logging.INFO):
    """设置logger, 同时输出到控制台和文件"""
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.handlers = []

    formatter = logging.Formatter('%(asctime)s | %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

    fh = logging.FileHandler(log_file, mode='w', encoding='utf-8')
    fh.setLevel(level)
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    ch = logging.StreamHandler()
    ch.setLevel(level)
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    return logger


logger = setup_logger('model2', 'model2_dual_branch_fusion.log')


# ========== 设置随机种子 ==========
def set_seed(seed=42):
    torch.manual_seed(seed)
    np.random.seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


set_seed(42)


# ========== 数据加载 (优化版, 与模型1共享) ==========
def load_gas_data(data_dir, gas_type='both', target_length=500, downsample_factor=10):
    """
    加载大论文-数据集中的气体传感器数据 (优化版)

    核心改进:
        1. 基线校正: 计算 ΔR/R₀ (相对阻值变化率), 消除传感器个体差异
        2. 降采样: 原始0.01s间隔 -> 0.1s间隔, 减少冗余噪声
        3. 多尺度特征: ΔR/R₀ + 一阶导数 + 滑动统计量
    """
    concentration_mapping = {
        "010": 25.0, "020": 50.0, "030": 75.0, "040": 100.0, "050": 125.0,
        "060": 150.0, "070": 175.0, "080": 200.0, "090": 225.0, "100": 250.0
    }

    data_list = []
    labels = []
    gas_labels = []
    file_names = []

    dirs_to_load = []
    if gas_type in ('Ac', 'both'):
        dirs_to_load.append(('Ac', 'GAC'))
    if gas_type in ('Ea', 'both'):
        dirs_to_load.append(('Ea', 'GEa'))

    for dir_name, gas_code in dirs_to_load:
        gas_dir = os.path.join(data_dir, dir_name)
        files = sorted(glob.glob(os.path.join(gas_dir, '*.txt')))
        logger.info(f"  [{dir_name}] 发现 {len(files)} 个文件, 开始加载...")
        load_start = time.time()

        for file_path in tqdm(files, desc=f"    加载{dir_name}", ncols=80):
            fname = os.path.basename(file_path)
            try:
                parts = fname.split('F')
                concentration_str = parts[1][:3]
                if concentration_str not in concentration_mapping:
                    continue
                concentration = concentration_mapping[concentration_str]
            except (IndexError, ValueError):
                continue

            try:
                raw_data = pd.read_csv(file_path, sep='\s+', header=None).values
            except Exception:
                continue
            if raw_data.ndim != 2 or raw_data.shape[1] < 5:
                continue

            time_col = raw_data[:, 0]
            sensor_data = raw_data[:, 1:5]

            # 基线校正 ΔR/R₀
            baseline_mask = time_col < 40
            if baseline_mask.sum() < 50:
                baseline_mask = np.arange(len(time_col)) < 500
            baseline = sensor_data[baseline_mask].mean(axis=0)
            delta_r = (sensor_data - baseline) / (np.abs(baseline) + 1e-8)

            # 响应区间 + 降采样
            response_mask = (time_col >= 40) & (time_col <= 290)
            delta_r_resp = delta_r[response_mask]

            if delta_r_resp.shape[0] < 100:
                continue

            delta_r_ds = delta_r_resp[::downsample_factor]

            # 多尺度特征工程
            n_points = delta_r_ds.shape[0]
            feat_delta_r = delta_r_ds
            feat_deriv = np.gradient(delta_r_ds, axis=0)
            window = min(20, n_points // 5)
            if window < 3:
                window = 3
            feat_std = np.zeros_like(delta_r_ds)
            for i in range(n_points):
                start_w = max(0, i - window // 2)
                end_w = min(n_points, i + window // 2 + 1)
                feat_std[i] = delta_r_ds[start_w:end_w].std(axis=0)

            combined = np.hstack([feat_delta_r, feat_deriv, feat_std])  # (n, 12)

            tensor_data = torch.tensor(combined, dtype=torch.float32)

            # 统一长度 (不做逐样本归一化, 保留幅度信息!)
            if tensor_data.shape[0] > target_length:
                indices_sel = np.linspace(0, tensor_data.shape[0] - 1, target_length, dtype=int)
                tensor_data = tensor_data[indices_sel]
            elif tensor_data.shape[0] < target_length:
                pad = torch.zeros(target_length - tensor_data.shape[0], tensor_data.shape[1])
                tensor_data = torch.cat([tensor_data, pad], dim=0)

            data_list.append(tensor_data)
            labels.append(concentration)
            gas_labels.append(0 if gas_code == 'GAC' else 1)
            file_names.append(fname)

        load_elapsed = time.time() - load_start
        logger.info(f"  [{dir_name}] 加载完成, 耗时 {load_elapsed:.1f}s")

    # ====== 全局归一化: 跨所有样本计算统计量, 保留浓度幅度差异 ======
    if len(data_list) > 0:
        all_data = torch.stack(data_list)  # (N, seq_len, 12)
        global_mean = all_data.mean(dim=(0, 1), keepdim=True)  # (1, 1, 12)
        global_std = all_data.std(dim=(0, 1), keepdim=True) + 1e-8  # (1, 1, 12)
        all_data = (all_data - global_mean) / global_std
        data_list = [all_data[i] for i in range(all_data.shape[0])]
        logger.info(f"\n  全局归一化: mean范围=[{global_mean.squeeze().min():.4f}, {global_mean.squeeze().max():.4f}]")
        logger.info(f"              std范围=[{global_std.squeeze().min():.4f}, {global_std.squeeze().max():.4f}]")

    logger.info(f"\n加载完成: {len(data_list)} 个样本")
    if gas_type == 'both':
        ac_count = sum(1 for g in gas_labels if g == 0)
        ea_count = sum(1 for g in gas_labels if g == 1)
        logger.info(f"  丙酮(Ac): {ac_count}, 乙醇(Ea): {ea_count}")
    unique, counts = np.unique(labels, return_counts=True)
    logger.info(f"  浓度分布: {dict(zip(unique, counts))}")

    return data_list, labels, gas_labels


# ========== 数据增强 ==========
def augment_data(sensor_data):
    augmented = sensor_data.clone()
    if np.random.random() > 0.5:
        noise = torch.randn_like(augmented) * 0.02 * torch.std(augmented)
        augmented = augmented + noise
    if np.random.random() > 0.5:
        scale = torch.rand(1).item() * 0.1 + 0.95
        augmented = augmented * scale
    if np.random.random() > 0.5:
        shift = np.random.randint(-50, 50)
        augmented = torch.roll(augmented, shifts=shift, dims=0)
    return augmented


# ========== 数据集类 ==========
class GasDataset(torch.utils.data.Dataset):
    def __init__(self, data_list, labels, augment=False):
        self.data_list = data_list
        self.labels = torch.tensor(labels, dtype=torch.float32)
        self.augment = augment

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        data = self.data_list[idx]
        label = self.labels[idx]
        if self.augment and torch.rand(1).item() > 0.5:
            data = augment_data(data)
        return data, label


# ==========================================
# 模型2: 双分支CNN-LSTM + 交叉注意力 + 自适应融合
# ==========================================

class ResidualCNNBlock(nn.Module):
    """残差CNN块: 带跳跃连接的卷积模块, 防止深层退化"""
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1):
        super().__init__()
        padding = kernel_size // 2
        self.conv_path = nn.Sequential(
            nn.Conv1d(in_channels, out_channels, kernel_size, stride=stride, padding=padding),
            nn.BatchNorm1d(out_channels),
            nn.GELU(),
            nn.Conv1d(out_channels, out_channels, kernel_size, stride=1, padding=padding),
            nn.BatchNorm1d(out_channels),
        )
        # 跳跃连接 (维度匹配)
        self.shortcut = nn.Sequential(
            nn.Conv1d(in_channels, out_channels, kernel_size=1, stride=stride),
            nn.BatchNorm1d(out_channels),
        ) if in_channels != out_channels or stride != 1 else nn.Identity()

        self.activation = nn.GELU()

    def forward(self, x):
        return self.activation(self.conv_path(x) + self.shortcut(x))


class SpatialAttention(nn.Module):
    """空间注意力: 对CNN输出的通道维度进行自适应加权"""
    def __init__(self, channels):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.max_pool = nn.AdaptiveMaxPool1d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels * 2, channels // 2),
            nn.GELU(),
            nn.Linear(channels // 2, channels),
            nn.Sigmoid()
        )

    def forward(self, x):
        # x: (batch, channels, seq_len)
        b, c, _ = x.size()
        avg_w = self.avg_pool(x).view(b, c)
        max_w = self.max_pool(x).view(b, c)
        w = self.fc(torch.cat([avg_w, max_w], dim=1)).view(b, c, 1)
        return x * w


class TemporalSelfAttention(nn.Module):
    """时序自注意力: 对LSTM输出的时间步进行注意力加权"""
    def __init__(self, d_model, n_heads=4, dropout=0.1):
        super().__init__()
        self.attn = nn.MultiheadAttention(
            embed_dim=d_model, num_heads=n_heads,
            dropout=dropout, batch_first=True
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_model * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model * 2, d_model),
            nn.Dropout(dropout),
        )
        self.norm2 = nn.LayerNorm(d_model)

    def forward(self, x):
        # 自注意力 + 残差
        attn_out, _ = self.attn(x, x, x)
        x = self.norm1(x + attn_out)
        # FFN + 残差
        x = self.norm2(x + self.ffn(x))
        return x


class CrossAttention(nn.Module):
    """交叉注意力: 两个分支的特征互相查询, 增强信息交互
    
    分支A的特征作为Query, 分支B的特征作为Key/Value (反之亦然)
    使得每个分支都能利用另一分支的互补信息
    """
    def __init__(self, d_model, n_heads=4, dropout=0.1):
        super().__init__()
        # A查询B
        self.cross_attn_a2b = nn.MultiheadAttention(
            embed_dim=d_model, num_heads=n_heads,
            dropout=dropout, batch_first=True
        )
        # B查询A
        self.cross_attn_b2a = nn.MultiheadAttention(
            embed_dim=d_model, num_heads=n_heads,
            dropout=dropout, batch_first=True
        )
        self.norm_a = nn.LayerNorm(d_model)
        self.norm_b = nn.LayerNorm(d_model)

    def forward(self, feat_a, feat_b):
        # feat_a, feat_b: (batch, seq_len, d_model)
        # A用B的信息增强自己
        enhanced_a, _ = self.cross_attn_a2b(query=feat_a, key=feat_b, value=feat_b)
        enhanced_a = self.norm_a(feat_a + enhanced_a)
        # B用A的信息增强自己
        enhanced_b, _ = self.cross_attn_b2a(query=feat_b, key=feat_a, value=feat_a)
        enhanced_b = self.norm_b(feat_b + enhanced_b)
        return enhanced_a, enhanced_b


class AdaptiveGatedFusion(nn.Module):
    """自适应门控融合: 学习最优的双分支融合权重
    
    不同于简单拼接或求和, 门控机制可以根据输入动态调整
    每个分支的贡献比例, 实现更灵活的特征融合
    """
    def __init__(self, d_model):
        super().__init__()
        # 门控网络: 根据两个分支的特征计算融合权重
        self.gate = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.GELU(),
            nn.Linear(d_model, d_model),
            nn.Sigmoid()
        )
        # 融合后的投影
        self.projection = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.LayerNorm(d_model),
            nn.GELU(),
        )

    def forward(self, feat_a, feat_b):
        # feat_a, feat_b: (batch, d_model)
        combined = torch.cat([feat_a, feat_b], dim=-1)
        gate_weight = self.gate(combined)  # (batch, d_model), 值在0~1之间
        # 加权融合
        fused = gate_weight * feat_a + (1 - gate_weight) * feat_b
        fused = self.projection(fused)
        return fused


class DualBranchFusionModel(nn.Module):
    """
    模型2: 双分支CNN-LSTM + 交叉注意力 + 自适应门控融合

    数据流:
        Input (batch, seq_len, 8)
            │
            ├─ 分支A: 空间分支 (CNN)
            │    → ResidualCNN × 3 → 空间注意力 → 自适应池化
            │
            └─ 分支B: 时序分支 (LSTM)
                 → BiLSTM(2层) → 时序自注意力 → 自适应池化
            │
            ├─ 维度对齐投影
            │
            ├─ 交叉注意力 (双向信息交互)
            │
            ├─ 全局池化 (时序聚合)
            │
            ├─ 自适应门控融合
            │
            └─ MLP回归头 → 浓度预测值
    """
    def __init__(self, input_dim=12, cnn_channels=32, lstm_hidden=64,
                 fusion_dim=128, n_heads=4, dropout=0.3):
        super().__init__()

        # ====== 分支A: 空间分支 (深层残差CNN) ======
        self.cnn_branch = nn.Sequential(
            ResidualCNNBlock(input_dim, cnn_channels, kernel_size=7),
            nn.MaxPool1d(2),
            ResidualCNNBlock(cnn_channels, cnn_channels * 2, kernel_size=5),
            nn.MaxPool1d(2),
            ResidualCNNBlock(cnn_channels * 2, cnn_channels * 4, kernel_size=3),
            nn.MaxPool1d(2),
        )
        self.spatial_attn = SpatialAttention(cnn_channels * 4)
        self.cnn_proj = nn.Sequential(
            nn.Conv1d(cnn_channels * 4, fusion_dim, kernel_size=1),
            nn.BatchNorm1d(fusion_dim),
            nn.GELU(),
        )

        # ====== 分支B: 时序分支 (BiLSTM) ======
        self.lstm_branch = nn.LSTM(
            input_size=input_dim,
            hidden_size=lstm_hidden,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.2
        )
        self.temporal_attn = TemporalSelfAttention(
            d_model=lstm_hidden * 2,
            n_heads=n_heads,
            dropout=dropout
        )
        self.lstm_proj = nn.Linear(lstm_hidden * 2, fusion_dim)
        self.lstm_norm = nn.LayerNorm(fusion_dim)

        # ====== 交叉注意力 ======
        self.cross_attention = CrossAttention(
            d_model=fusion_dim,
            n_heads=n_heads,
            dropout=dropout
        )

        # ====== 全局池化 ======
        self.pool_a = nn.AdaptiveAvgPool1d(1)
        self.pool_b = nn.AdaptiveAvgPool1d(1)

        # ====== 自适应门控融合 ======
        self.fusion = AdaptiveGatedFusion(fusion_dim)

        # ====== MLP回归头 (简化) ======
        self.regressor = nn.Sequential(
            nn.Linear(fusion_dim, fusion_dim // 2),
            nn.BatchNorm1d(fusion_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),

            nn.Linear(fusion_dim // 2, fusion_dim // 4),
            nn.BatchNorm1d(fusion_dim // 4),
            nn.GELU(),
            nn.Dropout(dropout * 0.5),

            nn.Linear(fusion_dim // 4, 1)
        )

    def forward(self, x):
        # x: (batch, seq_len, input_dim)

        # ====== 分支A: CNN空间特征 ======
        x_cnn = x.permute(0, 2, 1)  # (batch, input_dim, seq_len)
        x_cnn = self.cnn_branch(x_cnn)  # (batch, cnn_channels*4, seq_len//8)
        x_cnn = self.spatial_attn(x_cnn)
        x_cnn = self.cnn_proj(x_cnn)  # (batch, fusion_dim, seq_len_a)
        feat_a = x_cnn.permute(0, 2, 1)  # (batch, seq_len_a, fusion_dim)

        # ====== 分支B: LSTM时序特征 ======
        x_lstm, _ = self.lstm_branch(x)  # (batch, seq_len, lstm_hidden*2)
        x_lstm = self.temporal_attn(x_lstm)  # (batch, seq_len, lstm_hidden*2)
        feat_b = self.lstm_norm(self.lstm_proj(x_lstm))  # (batch, seq_len, fusion_dim)

        # ====== 对齐序列长度 (取较短的) ======
        min_len = min(feat_a.size(1), feat_b.size(1))
        # 对较长的分支做自适应池化对齐
        if feat_a.size(1) != min_len:
            feat_a = F.adaptive_avg_pool1d(
                feat_a.permute(0, 2, 1), min_len
            ).permute(0, 2, 1)
        if feat_b.size(1) != min_len:
            feat_b = F.adaptive_avg_pool1d(
                feat_b.permute(0, 2, 1), min_len
            ).permute(0, 2, 1)

        # ====== 交叉注意力 ======
        feat_a, feat_b = self.cross_attention(feat_a, feat_b)

        # ====== 全局池化 ======
        # (batch, seq_len, fusion_dim) -> (batch, fusion_dim)
        vec_a = self.pool_a(feat_a.permute(0, 2, 1)).squeeze(-1)
        vec_b = self.pool_b(feat_b.permute(0, 2, 1)).squeeze(-1)

        # ====== 自适应门控融合 ======
        fused = self.fusion(vec_a, vec_b)  # (batch, fusion_dim)

        # ====== MLP回归 ======
        out = self.regressor(fused).squeeze(-1)
        return out


# ========== 训练与评估工具 ==========

class EarlyStopping:
    def __init__(self, patience=30, min_delta=1e-5):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.early_stop = False

    def __call__(self, val_loss):
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss > self.best_loss - self.min_delta:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_loss = val_loss
            self.counter = 0
        return self.early_stop


def train_one_epoch(model, loader, optimizer, criterion, device, epoch=0, total_epochs=0):
    model.train()
    total_loss = 0
    pbar = tqdm(loader, desc=f"  Epoch {epoch+1:3d}/{total_epochs} [训练]",
                ncols=100, leave=False)
    for batch_idx, (X_batch, y_batch) in enumerate(pbar):
        X_batch = X_batch.to(device)
        y_batch = y_batch.to(device)

        optimizer.zero_grad()
        preds = model(X_batch)
        loss = criterion(preds, y_batch)

        l2_norm = sum(p.pow(2).sum() for p in model.parameters())
        loss = loss + 5e-5 * l2_norm

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        total_loss += loss.item()

        pbar.set_postfix(loss=f"{loss.item():.4f}")

    return total_loss / len(loader)


def evaluate(model, loader, criterion, device, desc="验证"):
    model.eval()
    total_loss = 0
    all_preds, all_targets = [], []

    with torch.no_grad():
        for X_batch, y_batch in tqdm(loader, desc=f"  [{desc}]", ncols=80, leave=False):
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)

            preds = model(X_batch)
            loss = criterion(preds, y_batch)
            total_loss += loss.item()

            all_preds.extend(preds.cpu().numpy())
            all_targets.extend(y_batch.cpu().numpy())

    all_preds = np.array(all_preds)
    all_targets = np.array(all_targets)

    mse = mean_squared_error(all_targets, all_preds)
    mae = mean_absolute_error(all_targets, all_preds)
    r2 = r2_score(all_targets, all_preds)

    return total_loss / len(loader), mse, mae, r2, all_preds, all_targets


def train_model(model, train_loader, val_loader, device, epochs=500, lr=2e-3):
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=3e-3)
    criterion = nn.HuberLoss(delta=1.0)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=1e-6)
    early_stopping = EarlyStopping(patience=60)

    best_r2 = -float('inf')
    best_state = None
    best_epoch = 0
    history = {'train_loss': [], 'val_loss': [], 'val_r2': []}

    total_start = time.time()
    logger.info(f"\n  训练配置: epochs={epochs}, lr={lr}, batch_size={train_loader.batch_size}")
    logger.info("-" * 100)

    for epoch in range(epochs):
        epoch_start = time.time()

        train_loss = train_one_epoch(model, train_loader, optimizer, criterion, device,
                                     epoch=epoch, total_epochs=epochs)
        val_loss, val_mse, val_mae, val_r2, _, _ = evaluate(model, val_loader, criterion, device, desc="验证")

        scheduler.step()
        history['train_loss'].append(train_loss)
        history['val_loss'].append(val_loss)
        history['val_r2'].append(val_r2)

        epoch_time = time.time() - epoch_start
        is_best = False
        if val_r2 > best_r2:
            best_r2 = val_r2
            best_epoch = epoch + 1
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
            is_best = True

        lr_now = optimizer.param_groups[0]['lr']
        best_mark = " ★ Best" if is_best else ""
        elapsed = time.time() - total_start
        eta = epoch_time * (epochs - epoch - 1)

        logger.info(f"  Epoch {epoch+1:4d}/{epochs} | "
              f"Train: {train_loss:.4f} | Val: {val_loss:.4f} | "
              f"R²: {val_r2:.4f} | MAE: {val_mae:.2f} | "
              f"LR: {lr_now:.6f} | "
              f"{epoch_time:.1f}s/epoch | "
              f"已用: {elapsed/60:.1f}min | "
              f"预计剩余: {eta/60:.1f}min{best_mark}")

        if early_stopping(val_loss):
            logger.info(f"\n  ✦ Early stopping at epoch {epoch+1} (patience={early_stopping.patience})")
            logger.info(f"    最佳验证R²: {best_r2:.4f} (epoch {best_epoch})")
            break

    total_time = time.time() - total_start
    logger.info("-" * 100)
    logger.info(f"  训练完成! 总耗时: {total_time/60:.1f}min ({total_time:.0f}s)")
    logger.info(f"  最佳验证R²: {best_r2:.4f} (epoch {best_epoch})")

    if best_state is not None:
        model.load_state_dict(best_state)
        logger.info(f"  已加载最佳模型权重 (epoch {best_epoch})")

    return model, history, best_r2


def plot_results(all_targets, all_preds, history, save_prefix='model2'):
    """绘制预测结果和训练曲线"""
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    # 1. 预测 vs 真实
    axes[0].scatter(all_targets, all_preds, alpha=0.6, s=30, c='coral', edgecolors='darkred', linewidths=0.5)
    min_val = min(all_targets.min(), all_preds.min()) - 10
    max_val = max(all_targets.max(), all_preds.max()) + 10
    axes[0].plot([min_val, max_val], [min_val, max_val], 'b--', linewidth=2)
    axes[0].set_xlabel('True Concentration (ppm)', fontsize=12)
    axes[0].set_ylabel('Predicted Concentration (ppm)', fontsize=12)
    axes[0].set_title('Prediction vs Ground Truth', fontsize=14)
    r2 = r2_score(all_targets, all_preds)
    axes[0].text(0.05, 0.95, f'R² = {r2:.4f}', transform=axes[0].transAxes,
                 fontsize=12, verticalalignment='top',
                 bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.5))

    # 2. 训练曲线
    axes[1].plot(history['train_loss'], label='Train Loss', linewidth=1.5, color='steelblue')
    axes[1].plot(history['val_loss'], label='Val Loss', linewidth=1.5, color='coral')
    axes[1].set_xlabel('Epoch', fontsize=12)
    axes[1].set_ylabel('Loss', fontsize=12)
    axes[1].set_title('Train / Val Loss', fontsize=14)
    axes[1].legend(fontsize=11)

    # 3. R²曲线
    axes[2].plot(history['val_r2'], color='seagreen', linewidth=1.5)
    axes[2].set_xlabel('Epoch', fontsize=12)
    axes[2].set_ylabel('R²', fontsize=12)
    axes[2].set_title('Validation R² Curve', fontsize=14)

    plt.tight_layout()
    plt.savefig(f'{save_prefix}_results.png', dpi=150, bbox_inches='tight')
    plt.show()
    logger.info(f"结果图已保存: {save_prefix}_results.png")


def plot_model_comparison(results_dict, save_path='model_comparison.png'):
    """绘制多模型对比图"""
    models = list(results_dict.keys())
    metrics = ['R²', 'RMSE', 'MAE', 'Rel. Error(%)']

    fig, axes = plt.subplots(1, 4, figsize=(20, 5))
    colors = ['steelblue', 'coral', 'seagreen', 'mediumpurple']

    for i, metric in enumerate(metrics):
        values = [results_dict[m][metric] for m in models]
        bars = axes[i].bar(models, values, color=colors[:len(models)], edgecolor='gray', linewidth=0.5)
        axes[i].set_title(metric, fontsize=14)
        axes[i].set_ylabel(metric, fontsize=11)
        for bar, val in zip(bars, values):
            axes[i].text(bar.get_x() + bar.get_width() / 2, bar.get_height(),
                         f'{val:.4f}', ha='center', va='bottom', fontsize=10)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.show()


# ========== 主程序 ==========
if __name__ == "__main__":
    from sklearn.model_selection import StratifiedKFold

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"使用设备: {device}")

    # 加载数据
    logger.info("\n" + "=" * 60)
    logger.info("Step 1/3: 加载数据")
    logger.info("=" * 60)
    data_start = time.time()
    data_dir = "./大论文-数据集"
    X_data, y_data, gas_labels = load_gas_data(data_dir, gas_type='both', target_length=500, downsample_factor=10)
    logger.info(f"数据加载总耗时: {time.time() - data_start:.1f}s")

    # 标签归一化: 25~250 ppm -> 0~1
    y_min, y_max = min(y_data), max(y_data)
    y_data_norm = np.array([(y - y_min) / (y_max - y_min) for y in y_data])
    y_data_arr = np.array(y_data)
    logger.info(f"\n数据集大小: {len(X_data)}")
    logger.info(f"数据形状: {X_data[0].shape}")
    logger.info(f"标签范围: {y_min:.0f} ~ {y_max:.0f} ppm (归一化到0~1)")

    input_dim = X_data[0].shape[1]

    # 5折分层交叉验证
    logger.info("\n" + "=" * 60)
    logger.info("Step 2/3: 5折分层交叉验证")
    logger.info("=" * 60)

    n_folds = 5
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)

    all_fold_preds = np.zeros(len(X_data))
    all_fold_targets = np.zeros(len(X_data))
    fold_r2_list = []
    fold_mae_list = []
    best_fold_model_state = None
    best_fold_r2 = -float('inf')

    for fold_i, (train_val_idx, test_idx) in enumerate(skf.split(range(len(X_data)), y_data)):
        logger.info(f"\n{'='*60}")
        logger.info(f"  Fold {fold_i+1}/{n_folds}")
        logger.info(f"{'='*60}")

        # 从train_val中再分出15%作为验证集
        from sklearn.model_selection import train_test_split
        tv_labels = [y_data[i] for i in train_val_idx]
        train_idx, val_idx = train_test_split(
            list(range(len(train_val_idx))), test_size=0.15, random_state=42, stratify=tv_labels
        )
        train_idx = [train_val_idx[i] for i in train_idx]
        val_idx = [train_val_idx[i] for i in val_idx]

        train_data = [X_data[i] for i in train_idx]
        train_labels = [y_data_norm[i] for i in train_idx]
        val_data = [X_data[i] for i in val_idx]
        val_labels = [y_data_norm[i] for i in val_idx]
        test_data = [X_data[i] for i in test_idx]
        test_labels = [y_data_norm[i] for i in test_idx]

        train_dataset = GasDataset(train_data, train_labels, augment=True)
        val_dataset = GasDataset(val_data, val_labels, augment=False)
        test_dataset = GasDataset(test_data, test_labels, augment=False)

        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=16, shuffle=True, num_workers=0)
        val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=16, shuffle=False, num_workers=0)
        test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=16, shuffle=False, num_workers=0)

        logger.info(f"  训练: {len(train_dataset)}, 验证: {len(val_dataset)}, 测试: {len(test_dataset)}")

        # 每折重新创建模型
        model = DualBranchFusionModel(
            input_dim=input_dim, cnn_channels=24, lstm_hidden=48,
            fusion_dim=96, n_heads=4, dropout=0.3
        ).to(device)

        if fold_i == 0:
            total_params = sum(p.numel() for p in model.parameters())
            logger.info(f"  模型参数: {total_params:,}")

        model, history, val_best_r2 = train_model(model, train_loader, val_loader, device, epochs=500, lr=2e-3)

        # 测试当前fold
        criterion = nn.HuberLoss(delta=1.0)
        _, _, _, _, preds_norm, targets_norm = evaluate(model, test_loader, criterion, device, desc=f"Fold{fold_i+1}测试")

        preds_ppm = preds_norm * (y_max - y_min) + y_min
        targets_ppm = targets_norm * (y_max - y_min) + y_min

        fold_r2 = r2_score(targets_ppm, preds_ppm)
        fold_mae = mean_absolute_error(targets_ppm, preds_ppm)
        fold_r2_list.append(fold_r2)
        fold_mae_list.append(fold_mae)

        # 保存预测结果到全局数组
        for j, idx in enumerate(test_idx):
            all_fold_preds[idx] = preds_ppm[j]
            all_fold_targets[idx] = targets_ppm[j]

        logger.info(f"  Fold {fold_i+1} 测试: R²={fold_r2:.4f}, MAE={fold_mae:.2f} ppm")

        if fold_r2 > best_fold_r2:
            best_fold_r2 = fold_r2
            best_fold_model_state = {k: v.clone() for k, v in model.state_dict().items()}

    # 汇总结果
    logger.info("\n" + "=" * 60)
    logger.info("Step 3/3: 5折交叉验证汇总")
    logger.info("=" * 60)

    overall_r2 = r2_score(all_fold_targets, all_fold_preds)
    overall_mse = mean_squared_error(all_fold_targets, all_fold_preds)
    overall_mae = mean_absolute_error(all_fold_targets, all_fold_preds)
    overall_rmse = np.sqrt(overall_mse)
    rel_err = np.mean(np.abs(all_fold_preds - all_fold_targets) / (all_fold_targets + 1e-8)) * 100

    logger.info(f"\n  各折R²: {[f'{r:.4f}' for r in fold_r2_list]}")
    logger.info(f"  各折MAE: {[f'{m:.2f}' for m in fold_mae_list]}")
    logger.info(f"\n  ---------- 5折交叉验证总结果 ----------")
    logger.info(f"  平均R²:  {np.mean(fold_r2_list):.4f} ± {np.std(fold_r2_list):.4f}")
    logger.info(f"  平均MAE: {np.mean(fold_mae_list):.2f} ± {np.std(fold_mae_list):.2f} ppm")
    logger.info(f"  全局R²:  {overall_r2:.4f}")
    logger.info(f"  全局RMSE: {overall_rmse:.4f}")
    logger.info(f"  全局MAE: {overall_mae:.4f}")
    logger.info(f"  全局相对误差: {rel_err:.2f}%")

    # 逐样本预测
    logger.info("\n--- 逐样本预测 (全部240样本) ---")
    sort_idx = np.argsort(all_fold_targets)
    for i in sort_idx:
        logger.info(f"  真实: {all_fold_targets[i]:7.2f} ppm | 预测: {all_fold_preds[i]:7.2f} ppm | "
              f"误差: {abs(all_fold_targets[i] - all_fold_preds[i]):6.2f}")

    # 绘图
    plot_results(all_fold_targets, all_fold_preds, {'train_loss': [], 'val_loss': [], 'val_r2': fold_r2_list},
                 save_prefix='model2_dual_branch_fusion')

    # 保存最佳fold的模型
    if best_fold_r2 > 0.85 and best_fold_model_state is not None:
        save_path = 'model2_dual_branch_fusion_best.pth'
        model.load_state_dict(best_fold_model_state)
        torch.save({
            'model_state_dict': best_fold_model_state,
            'best_fold_r2': best_fold_r2,
            'overall_r2': overall_r2,
            'overall_mae': overall_mae,
        }, save_path)
        file_size = os.path.getsize(save_path) / 1024 / 1024
        logger.info(f"\n最佳模型已保存: {save_path} ({file_size:.1f} MB)")
        logger.info(f"  最佳折R²={best_fold_r2:.4f}, 全局R²={overall_r2:.4f}")

    logger.info("\n" + "=" * 60)
    logger.info("全部流程完成!")
    logger.info("=" * 60)

